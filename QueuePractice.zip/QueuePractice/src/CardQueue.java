
public class CardQueue {

	public Card [] q;
	public int size;
	public int total;
	public int front;
	public int rear;
	
	public CardQueue() {
		size = 100;
		total = 0;
		front = 0;
		rear = 0;
		q = new Card [size];
		
	}
	
	public CardQueue(int size) {
		this.size = size;
		total = 0;
		front = 0;
		rear = 0;
		q = new Card [this.size];
	}
	
	public boolean enqueue(Card item) {
		if(isFull()) 
			return false;
		
		else 
			total++;
			q[rear] = item;
			rear = (rear +1) % size;
			return true;
		
		
	}
	
	public Card dequeue() {
		Card item = q[front];
		
		total--;
		front = (front +1) % size;

		return item;
	}
	
	public boolean isFull() {
		if(size == total)
			return true;
		
		else 
			return false;
	}
	
	public void seeQueue() {
		int f = front;
		if(total != 0) {
			for (int i = 0; i<total; i++) {
				System.out.println("" + q[f]);
				f = (f+1) % size;
			}
		}
	}
}
