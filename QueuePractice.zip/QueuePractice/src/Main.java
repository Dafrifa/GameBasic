
public class Main {
	public static void main(String[] args) {
//		IntQueue q = new IntQueue();
//		q.enqueue(3);
//		q.enqueue(2002);
//		q.enqueue(1);
//		q.enqueue(2);
//		q.enqueue(7);
//		
////		System.out.println(q.dequeue());
////		System.out.println(q.dequeue());
////		System.out.println(q.dequeue());
////		System.out.println(q.dequeue());
////	
//		
//		q.seeQueue();
		
		CardQueue deck = new CardQueue();
		deck.enqueue( new Card("Dark Magician", "Spellcaster", 2500));
		deck.enqueue(  new Card("Blue Eyes White Dragon", "Dragon", 3000));
		
		deck.seeQueue();

}
	
	
}
