package Game;

import java.awt.*;

public class DummySword extends PolygonModel
{
  public DummySword(int x, int y, int A)
  {
      super(x, y, A);
  }

  public int[][] struct_x()
  {
     final int[][] struct_x =
     {
        {5, 5, -5, -5},
        
        {27, 27, -27, -27},
        {27, 27, -27, -27},
     };

     return struct_x;
  }

  public int[][] struct_y()
  {
     final int[][] struct_y =
     {
        
        {0, 12, 32, -12},
        {-3, 3, 3, -3},
        {25, 32, 32, 25},
        
     };

     return struct_y;
  }
}







