package Game;

import java.awt.Graphics;

public class FollowBullet extends Sprite {


	boolean falling = false;

	static String[] action = { "G", "H", "I" };

	boolean active;
	boolean up;
	double basex;
	double basey;
	double xStart = x;

	static String part;
	
	static Animation PathBullet0 = new Animation("PathH_shot_", 4,6);
	static Animation[] PathBulletPlay = {PathBullet0};
	
	public FollowBullet(int x, int y) {
		super(x, y, "PathBullet", part);
		active = false;
		up = true;
		this.check();
		basex = x;
		basey = 750;
		
	}
	
	   public void check() {
		   this.w = 5;
		   this.h = 5;
	   }

	public void tick() {
		
		if (active) {
			if(Game.s.x < x) 
				x -= .5;
				else 
				x += .5;
			if(Game.s.y < y-5)
			y -= .5;
			else
				y += .5;
			if (x < xStart-1000) {
				active = false;
			}
			
			if (overlaps(Game.s)) {
				System.out.println("Hit");

				active = false;
				this.fireReset();
				//TODO: When Player is completed, decrease health.
			}
		}
		if(!active) {

		}
		
	}
	
	public void setFalse() {
		active = false;
	}
	
	public void fireReset() {
		x = -100;
		y = -100;
	}

	public void draw(Graphics g) {
		g.drawRect((int) x, (int) y, w, h);
		if (moving)
			g.drawImage(PathBulletPlay[0].nextImage(), (int) x, (int) y, 5, 5, null);
		else
			g.drawImage(PathBulletPlay[0].nextImage(), (int) x, (int) y, 5, 5, null);
		
		
	}
}
