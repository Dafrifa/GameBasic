package Game;

import java.awt.Color;
import java.awt.Graphics;

public class Enemy extends Sprite
{
   static String[] Enemyaction = {"st", "rn", "atk"};
   static int target = 1; 
   static int speed = 1;
   static String part;
   
   static Animation Enemation0 = new Animation("chopper_st_", 2,10);
   static Animation Enemation1 = new Animation("NME_rn_", 2,10);
   static Animation Enemation2 = new Animation("NME_atk_", 2,9);
   
   
   static Animation[] ENEMYplay = {Enemation0,  Enemation1, Enemation2 };
   
   public Enemy(int x, int y, int speed)
   {
      super(x, y, "NME_", part);
      

      
   }
   
   
   
   public Animation playAnimation() {   
		for(int i = 0; i < ENEMYplay.length; i++) {
			if(this.checkPose() == i)
				return ENEMYplay[i];
		}
		return ENEMYplay[8];
   }

   
   
   public void check() {
	   this.w = w+15;
	   this.h = h-10;
   }
   
   public void setSpeed(){
	   speed = 1;
   }
   
   public static int animationSpeed ()
   {
	   speed =10;
	   return speed;
   }
   
   public void draw(Graphics g)
   {
	   
	   if (!act && !moving && !inAir)
		   g.drawImage(this.playAnimation().nextImage(), (int)x, (int)y, null);
		   else
	   g.drawImage(this.playAnimation().nextImage(), (int)x, (int)y, null);
	  
     /* if(moving)
	   g.drawImage(animation[pose].nextImage(), (int)x, (int)y, null);
      
      else {
      
    	  if(inAir && !moving) {
    		  if (facingRight)
    		  pose = RFALL;
    		  else
    			  pose = LFALL;
   
    		  g.drawImage(animation[pose].nextImage(), (int)x, (int)y, null);
    
    	  	}
    	  else {
    		  if (facingRight)
    			//   pose = STAND;
    			//  else pose = STANDL;
         g.drawImage(animation[pose].nextImage(), (int)x, (int)y, null);
      }
      }
      
         moving = false;
         */
      g.setColor(Color.blue);
      if (selected) 
    	  //g.drawRect((int)x, (int)y,w+15,h-10);
   	  g.drawRect((int)x, (int)y,w,h);
      
      /*
      g.drawRect((int)x+5, (int)y+h-4, 25, 4);
      g.drawRect((int)x+5, (int)y, 25, 4);
      g.drawRect((int)x, (int)y, 5, h);
      g.drawRect((int)x+w-5, (int)y, 5, h);
      */
      g.setColor(Color.black);
      
   }

   
   
}