package Game;

import java.applet.Applet;

import java.awt.event.*;
import java.awt.*;

public class Game extends Applet implements KeyListener, Runnable, MouseListener, MouseMotionListener
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Image    off_screen;
    Graphics off_g;

    Graphics2D g2d = (Graphics2D) off_g;


   int space = 200;
   
   int checkOn = 0;
   
   //String[] action = {"st","lt","rt", "up", "dn"};
   
   boolean onIt;
   boolean notOnAnything;
   
   static Hero s = new Hero(200, 550, 10);
   PantheonH PantheonH1 = new PantheonH(1300, 611);
   PantheonH PantheonH2 = new PantheonH(1350, 611);
   PantheonW PantheonW1 = new PantheonW(1100, 611);
   PantheonH PantheonH3 = new PantheonH(500, 2964);
   PantheonH PantheonH4 = new PantheonH(3000, 2964);
   PantheonW PantheonW2 = new PantheonW(3500, 2900);
   
   PantheonH ph [] = {PantheonH1,PantheonH2,PantheonH3,PantheonH4};;
/*   PantheonW PantheonW1 = new PantheonW(1100, 411);
   PantheonH PantheonH1 = new PantheonH(1300, 411);
   PantheonH PantheonH2 = new PantheonH(1350, 411);
   PantheonW PantheonW1 = new PantheonW(1100, 411);
   */
   Camera cam;

   Rect enemy[] = {PantheonH1, PantheonH2, PantheonW1};
   Rect realBodies[] = {s, PantheonH1, PantheonH2, PantheonW1};

   Tile A [] = new Tile [6];
   Tile B [] = new Tile [4];
   //Tile C = new Tile (1900, 3100, 1000, 40, "Left.png");
   Tile elevateTile = new Tile (1900, 3100, 1000, 40, "Left.png");


   Tile M [] = new Tile [9];
   ImageLayer TopPart = new ImageLayer("Surface.png", 0, 0, 100);
   ImageLayer Mid     = new ImageLayer("deepB.png", 0, 2300, 100);
   ImageLayer houses    = new ImageLayer("houses.gif",0, 0, 10);

   Animation E0 = new Animation("chopper_st_", 3,1);
   Animation E1 = new Animation("NME_st_", 4,15);
   Animation E2 = new Animation("NME_atk_", 5,30);
   
   Animation anim6 = new Animation("Zero_fl_", 5,10);
   Animation anim7 = new Animation("Zero_fr_", 5,10);
   Animation anim0 = new Animation("Zero_st_", 5,1);
   Animation anim1 = new Animation("Zero_stl_", 5,1);
   Animation anim2 = new Animation("Zero_rt_", 5,10);
   Animation anim3 = new Animation("Zero_lt_", 5,10);
   Animation anim4 = new Animation("Zero_jp_", 5,10);
   Animation anim5 = new Animation("Zero_jplt_", 5,10);
   Animation anim8 = new Animation("Zero_atk_", 10,3);
   Animation anim9 = new Animation("Zero_atkl_", 10,30);
   
   static Animation C0 = new Animation("PH_st_", 3,10);
   static Animation C1 = new Animation("PH_rnL_", 3,10);
   static Animation C2 = new Animation("PH_atk_", 2,10);
   static Animation C3 = new Animation("PH_aim_", 3,10);
   static Animation C4 = new Animation("PH_hold_", 3,10);
   static Animation C5 = new Animation("PH_str_", 3,10);
   static Animation C6 = new Animation("PH_rnR_", 3,10);
   static Animation C7 = new Animation("PH_atkR_", 2,10);
   static Animation C8 = new Animation("PH_aimR_", 3,10);
   static Animation C9 = new Animation("PH_holdR_", 3,10);
   static Animation Ck = new Animation("BLANK", 5,10);
   
   static Animation PW0 = new Animation("PathW_st_", 3,10);
   static Animation PW1 = new Animation("PathW_gearOne_", 3,10);
   static Animation PW2 = new Animation("PathW_gearTwo_", 2,10);
   static Animation PW3 = new Animation("PathW_strikeOne_", 3,10);
   static Animation PW4 = new Animation("PathW_strikeTwo_", 3,10);
   static Animation PW5 = new Animation("PathW_coolOne_", 3,10);
   static Animation PW6 = new Animation("PathW_coolTwo_", 3,10);
   static Animation PW11 = new Animation("PathW_strikeTwoR_", 3,10);

   Thread t;
   boolean control = true;
   boolean st_active = true;
   boolean lt_Pressed = false;
   boolean rt_Pressed = false;
   boolean up_Pressed = false;
   boolean dn_Pressed = false;
   boolean sp_pressed = false;
   boolean sp_released = false;
   boolean attk_pressed = false;
   boolean key_Released = false;
 


   boolean overlap = false;
   boolean attack_1 = false;
   boolean attack_roll = false;
   
   double grav = s.getY();
   int mx;
   int my;

   public void init()
   {
	  
	  setSize(1000,1000);
      off_screen = this.createImage(5000, 5000);
      off_g      = off_screen.getGraphics();
      s.check();
      //PantheonH1.check();
      for (int i =0; i<ph.length; i++) {
    	  ph[i].check();
      }
      PantheonW1.check();
      cam = new Camera(0,0);
      B[0] = new Tile (150, 650, 5000, 40, "Middle.png");
      B[1] = new Tile (150, 3000,1200, 40, "Middle.png");
      B[2] = new Tile (2000, 3000, 3000, 40, "Middle.png");
      B[3] = new Tile (250, 2000, 5000, 40, "Middle.png");
     
      A[0] = new Tile (150, 3100, 50, 400, "Right.png");
      A[1] = new Tile (1150, 3000, 50, 400, "Right.png");
      A[2] = new Tile (1300, 3000, 50, 400, "Right.png");
      A[3] = new Tile (1450, 3000, 50, 400, "Right.png");
      A[4] = new Tile (1600, 3000, 50, 400, "Right.png");
      A[5] = new Tile (1750, 3000, 50, 400, "Right.png");

      
      requestFocus();
      addKeyListener(this);

      addMouseListener(this);
      addMouseMotionListener(this);

      t = new Thread(this);

      t.start();
   }

   public void run()
   {
      while(true)
      {  
    	  if (s.health == 0)
    		  control = false;
    	  s.inAir = true;
    	  maverick();
    	  cam.followCharacter(s);
    	  
    	  if(s.inAir)
    	  s.trueG(2.8);
    	  
    	  for (int i = 0; i <A.length; i++) {
    	  A[i].floatingMove();
    	  }
    	  
          for(int i = 0; i < ph.length; i++) {
          ph[i].ERI();
          }
          
    	 PantheonW1.ERI();
    	  grav = s.getY();

    	  
    	  
    	  
    	  if (s.checkAir()) {
    		 s.falling();
    	  }
    	  
    	  
               if(up_Pressed){   s.moveUpBy(2);   }
               
               if(dn_Pressed){   
            	  // if(!onIt)
            	   s.moveDownBy(2);
            	   
               }
               
               
               
               
               if(lt_Pressed)
               {
                  s.moveLeftBy(2);
                  onIt = false;
                  TopPart.moveRightBy(20);
                  houses.moveRightBy(20);
                  Mid.moveRightBy(20);
            	  
               }
               if(rt_Pressed)
               {
            	   onIt = false;
                  s.moveRightBy(2);
                  TopPart.moveLeftBy(20);
                  houses.moveLeftBy(20);
                  Mid.moveLeftBy(20);
            	   
               }
                       
               if(sp_pressed && !sp_released) {
            	   
            	   s.Jump();
            	   
            	   
                   if (grav < s.getY()) {
                  	
                	 //s.moveUpBy(1.5);
                  	 s.falling();
                  	 //s.trueG(0);
                  	 grav = s.getY();
                  	 //s.move();
                  	 
                   }
                   
                   else {s.reset();}

               }
               /*
               if (sp_released) { 
            	  
                   if (grav < s.getY()) {
                	   s.moveUpBy(3.5);
                    	 s.falling();
                    	 //s.trueG(1);
                    	// s.move();
                    	 
                     }
            	   
               }
               */
               if(!sp_pressed && s.checkAir()) 

            	   s.noJump();
               
              if (!s.checkAir())
            	  s.reset();
              
              if((attk_pressed && s.pose <= 1) || (attk_pressed && s.pose >= 4 && s.pose <= 7)) { 
            	  attack_1 = true;
              }
              
              if((attk_pressed && s.pose == 2) || (attk_pressed && s.pose == 3)) {
                  
            	  attack_roll = true;
            	
              }
              
              if(attack_1) {
            	  s.attackAnimation1(); 
            	  attack_1 = false;
              }
              
              if(attack_roll) {
            	  s.attackAnimationRoll(); 
            	  attack_roll = false;
              }
              
              if(s.getAttackPermission() == true && key_Released) {
            	  attk_pressed = false;
            	  s.resetAttackPermission();
            	  s.resetAttack();
              }
              
              if(s.getRightX()>4000) {
             	 s.setLocation(150, 2900);
              s.reset();
              }
         repaint();

         try
         {
             t.sleep(15);
         }
         catch(Exception x){}
      }

   }


   public void update(Graphics g)
   {
	   
		  if(s.getY()<1200)
		  off_g.clearRect(0, 0, 200, 1000);
		  if(s.getY()>1200 && s.getY()<5000)
		  off_g.clearRect(0, 2000, 5000, 1000);
	      paint(off_g);
	      
	    
	      g.drawImage(off_screen, (int)-s.getX()+100, (int)-s.getY()+400, this);


   }
   
   public void scroll() {
	   mx -=s.getX();
   }

   public void elevator() {
	   double sXPos = s.getRightX();
	   double sYPos = s.getBottomY();

   
	   if ((sYPos<elevateTile.getY()) && sYPos > elevateTile.getY()-200) {
		   if ((sXPos>elevateTile.getX()) && s.getX()<elevateTile.getRightX()){
			   s.falling();
			   s.trueG(0);
			   s.reset();
			   s.moveGup();
			   //s.moveBy(0, (int)-.9);
			   //s.moveBy(0, -20);
		   }
		  
	   }
	   else s.Ureset();
   }
   public void maverick() {
	   
	   double sXPos = s.getRightX();
	   double sYPos = s.getBottomY();
      
	   for (int i = 0; i <A.length; i++) {
		   
	    double aXPos = A[i].getRightX();
	    
         if ((sYPos>A[i].getY()) && (s.getNearBottomY() < A[i].getY())){
         	if ((sXPos>A[i].getX()) && s.getX()<aXPos){

           	  	  s.reset();
         		  s.stopAir();
         		  s.resetJump();
         		  sp_released = false;
         		  s.onGround();
         		  s.trueG(0);
 		 onIt = true;
 		 checkOn = i;
 		//System.out.println("Check A: " + i);
       }
            else {
            	if(!onIt) {
          		s.falling();
          		//System.out.println("Check A: " + i);
            	}
          	}	
         	
       }
         
         
	   }
         for (int i = 0; i <B.length; i++) {
         double bXPos = B[i].getRightX();
         
         if ((sYPos>B[i].getY()) && (s.getNearBottomY() < B[i].getY())){
         	if ((sXPos>B[i].getX()) && s.getX()<bXPos){
         	  s.reset();
       		  s.stopAir();
       		  s.resetJump();
       		  sp_released = false;
       		  s.onGround();
       		s.trueG(0);
       		onIt = true;
       		//System.out.println("Check B: " + i);
       }
            else {
            	if(!onIt) {
          		s.falling();
          		//System.out.println("Check B: " + i);
            	}
          	}
        }

	   }
   }

   public void paint(Graphics g)
   {
	   double sXPos = s.getRightX();
	   double sYPos = s.getBottomY();



	   elevator();
          TopPart.draw(g);
          Mid.draw(g);
       //   houses.draw(g);
   	   for (int i = 0; i <A.length; i++) {
   		   double aXPos = A[i].getRightX();
   		   double aYPos = A[i].getBottomY();
          if (sXPos > A[i].getX() && s.getX()< A[i].getX()){
              if ((s.getY()<aYPos)&&(s.getNearBottomY() > A[i].getY())){       
        		  s.moveBy((int)(sXPos - A[i].getX())*(-1), 0);
        		   
        	  }
              }
          
          if (s.getX() < aXPos && sXPos>aXPos){
        	  if ((s.getY()<aYPos)&&(s.getNearBottomY() > A[i].getY())){
         
        		  s.moveBy((int)(aXPos - s.getX()), 0);
        		   
        	  
              }
          }
             
           
          if ((sYPos>A[i].getY()) && (s.getNearBottomY() < A[i].getY())){
          	if ((sXPos>A[i].getX()) && s.getX()<aXPos){

        		
        	
        	s.moveBy(0, (int)(sYPos - A[i].getY())*(-1));

        }
         }
   	   }
          for (int i = 0; i <B.length; i++) {
       	   double bXPos = B[i].getRightX();
    	   double bYPos = B[i].getBottomY();
          
          if ((sYPos>B[i].getY()) && (s.getNearBottomY() < B[i].getY())){
            	if ((sXPos>B[i].getX()) && s.getX()<bXPos){

                    //keep this so falling object that hit the floor can repeatedly come back;
               		// as if they were brand new objects. Be sure to animate their destruction though
               		//s.moveBy(0, (int)(-500));
          	
          	s.moveBy(0, (int)(sYPos - B[i].getY())*(-1));
  
          	
          }
           }
   }

          for (int i = 0; i <A.length; i++) {
          A[i].draw(g);
          }
          for (int i = 0; i <B.length; i++) {
          B[i].draw(g);
          }
          elevateTile.draw(g);
          
          /*
          for(int i = 0; i < M.length; i++) {
              M[i].draw(g);
              
              
              if (sXPos > M[i].getX() && s.getX()< M[i].getX()){
                  if ((s.getY()<M[i].getBottomY())&&(s.getNearBottomY() > M[i].getY())){
                	       
            		  s.moveBy((int)(sXPos - M[i].getX())*(-1), 0);
            		   
            	  }
                  }
              
              
              if (s.getX() < M[i].getRightX() && sXPos>M[i].getRightX()){
            	  if ((s.getY()<M[i].getBottomY())&&(s.getNearBottomY() > M[i].getY())){      
            		  s.moveBy((int)(M[i].getRightX() - s.getX()), 0);
            		   
            	  
                  }
              }
                 
               
                
            if ((sYPos>M[i].getY()) && (s.getNearBottomY() < M[i].getY())){
            	if ((sXPos>M[i].getX()) && s.getX()<M[i].getRightX()){
            		
            	//s.trueG(0);
            	s.moveBy(0, (int)(sYPos - M[i].getY())*(-1));
            	s.stopAir();
            	s.resetJump();
            	sp_released = false;
            	setG = true;
            	
            }
            	
            	
            	
             }
     
           
            
              space+= 100;
          }
          */
          
          
          s.draw(g);
          for (int i = 0; i <ph.length; i++) {
          ph[i].draw(g);
          }
          PantheonW1.draw(g);
/*
  		String print = new String ("Facing: "+s.facingRight);
        g.drawString(print, (int)(s.x-100), (int)s.y-100);
        
        String rint = new String ("inAir: "+s.inAir);
        g.drawString(rint,  (int)(s.x-75), (int)s.y-75);
        
        String rush = new String ("CheckG: "+s.checkG());
        g.drawString(rush, (int)(s.x-50), (int)s.y-50);

        String ush = new String ("On: "+ onIt);
        g.drawString(ush, (int)(s.x-25), (int)s.y-25);
*/
        String print = new String ("Grav "+grav);
        String sprint = new String ("s.Y "+s.getY());
        String check = new String ("Falling: "+s.checkAir());
        String facingRight = new String ("FacingRight: " +s.isFacingRight());
        String gravityCheck = new String ("Gravity: " +s.checkG());
        //String DistanceCheck = new String ("Distance: " + (tankO.getX() - s.getX()));
        String Poser = new String ("Pose: " +s.checkPose());
        
        
        String Jump = new String ("Attacked : " +this.checkAttkPress());
        String Release = new String ("keyRelease: " +this.checkKeyRelease());
        
        String attack1 = new String ("Attack1: " + attack_1);
        g.drawString(print, 300, 100);
        g.drawString(sprint, 300, 150);
   //     g.drawString(Jump, 300, 100);
   //     g.drawString(Jump, 400, 100);
   //     g.drawString(Release, 300, 150);
   // 	g.drawString(DistanceCheck, 300, 200);
   //     g.drawString(Poser, 300, 250);
   //     g.drawString(check, 0, 220);
        
   //     g.drawString(facingRight, 0, 320);
   //     g.drawString(gravityCheck, 0, 400);
        
          
          
          
          
   }

   public boolean checkJumpPress() {
	   return sp_pressed;
   }
   
   public boolean checkAttkPress() {
	   return attk_pressed;
   }
   
   public boolean checkJumpRelease() {
	   return sp_released;
   }
   
   public boolean checkKeyRelease() {
	   return key_Released;
   }
   
   public void mouseMoved(MouseEvent e)
   {
   }

   public void mouseDragged(MouseEvent e)
   {



   }



   public void mousePressed(MouseEvent e)
   {

   }

   public void mouseReleased(MouseEvent e)
   {

   }

   public void mouseClicked(MouseEvent e)
   {

   }

   public void mouseEntered(MouseEvent e)
   {

   }

   public void mouseExited(MouseEvent e)
   {

   }

   


   public void keyPressed(KeyEvent e)
   {
	   
	   if(control) {
		   
      int code = e.getKeyCode();
      if(code == KeyEvent.VK_LEFT)     lt_Pressed = true;
      if(code == KeyEvent.VK_RIGHT)    rt_Pressed = true;
      if(code == KeyEvent.VK_UP)       up_Pressed = true;
      if(code == KeyEvent.VK_DOWN)     dn_Pressed = true;
      
      if(code == KeyEvent.VK_SPACE) {
    	  sp_pressed  = true;
    	 
      }
      
      if(code == KeyEvent.VK_D) {
    	  attk_pressed = true;
    	  key_Released = false;
      }
      
	   }
   }

   public void keyReleased(KeyEvent e)
   {
	   if(control) {
		   
	   
      int code = e.getKeyCode();

      if(code == KeyEvent.VK_LEFT)     lt_Pressed = false;
      if(code == KeyEvent.VK_RIGHT)    rt_Pressed = false;
      if(code == KeyEvent.VK_UP)       up_Pressed = false;
      if(code == KeyEvent.VK_DOWN)     dn_Pressed = false;
      
      if(code == KeyEvent.VK_SPACE) {    
    	  sp_pressed =  false; 
    	  sp_released = true;
      }
      
      if(code == KeyEvent.VK_D) {
    	  //attk_pressed = false;
    	  key_Released = true;
      }
   }
   }

   public void keyTyped(KeyEvent e) { 
	   
   }


}