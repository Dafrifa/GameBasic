package Game;

import java.awt.Graphics;
import java.util.Random;

public class Chop extends Sprite {
	boolean falling = false;
	boolean hurt = false;
	boolean sparked = false;
	boolean charged = false;
	boolean attacked = false;
	boolean ran = false;
	boolean taunted = false;
	boolean stun = false;
	boolean roundBoom = false;
	boolean boomPlacement = false;
	boolean ERII_Complete = false;

	static String[] action7 = {"st", "rn", "atk"};

	static final int STAND = 0;
	static final int RUN = 1;
	static final int ATTACK = 2;

	int state = 0;
	
	static String part;

	int playerx, playery, lastplayerx, lastplayery;
	int Chopx, Chopy;

	int still_count;

	int ball_timer, ball_delay, ball_anim_timer, ball_anim_delay,boom_timer, boom_delay, boom_anim_timer, boom_anim_delay, stand_timer, stand_delay, stun_timer, stun_delay, reset_timer, reset_delay;
	DropDownBlast[] balls;
	//FlameBlast[] fire;
	BombBlast[] boom;
	int gravity = 0;
	int knockback = 0;
	int current_ball = 0;
	int current_fire = 0;
	int current_bomb = 0;
	int hp = 100;
	int rand_jump_timer;
	
	   static Animation Chopanim0 = new Animation("chop_st_", 3,40);
	   static Animation Chopanim1 = new Animation("chop_rn_", 3,8);
	   static Animation Chopanim2 = new Animation("chop_atk_", 6,30);
	   static Animation Chopblank = new Animation("BLANK", 5,10);
	   
	   static Animation[] Chopplay = {Chopanim0, Chopanim1, Chopanim2};
	   
	Random randy = new Random();

	public Chop(int x, int y) {
		super(x, y, "chop_", part);

		ball_delay = 20*7;
		ball_timer = ball_delay;
		ball_anim_delay = 20 * 7;
		ball_anim_timer = 0;
		boom_delay = 20*7;
		boom_timer = boom_delay;
		boom_anim_delay = 20 * 7;
		boom_anim_timer = 0;
		still_count = 0;
		stand_delay = 720;
		stand_timer = stand_delay;
		stun_delay = 180;
		stun_timer = stun_delay;
		reset_delay = 180;
		reset_timer = reset_delay;
		balls = new DropDownBlast[3];
		balls[0] = new DropDownBlast(-100, -100);
		balls[1] = new DropDownBlast(-100, -100);
		balls[2] = new DropDownBlast(-100, -100);
		
/*
		fire = new FlameBlast[3];
		fire[0] = new FlameBlast(-100, -100);
		fire[1] = new FlameBlast(-100, -100);
		fire[2] = new FlameBlast(-100, -100);
	*/	

		boom = new BombBlast[3];
		boom[0] = new BombBlast(-100, -100);
		boom[1] = new BombBlast(-100, -100);
		boom[2] = new BombBlast(-100, -100);

	}
	
	   public Animation playAnimation() {   
			for(int i = 0; i < Chopplay.length; i++) {
				if(state == i)
					return Chopplay[i];
			}
			return Chopblank;
	   }

	 
	   
	  public int checkState(){
		  return state;
	   }
	  
	   public void check() {
		   this.w = w+14;
		   this.h = h-19;
	   }
	   
	   public void painCheck() {
		   if (this.overlaps(Game.s)) {
			   hurt = true;
		   	   sparked = true;
		   	knockback = 10;
		   	   
		   }
		   
	   }
	   
	   public void effortReset() {
			charged = false;
			attacked = false;
			ran = false;
			taunted = false;
			stand_timer = stand_delay;
			ball_timer = ball_delay;
			ball_anim_timer = ball_anim_delay;
	   }
	   
	   public void secondEffortReset() {
		   effortReset();
		   stun = false;
		   roundBoom = false;
		   boomPlacement = false;
		   ERII_Complete = false;
	   }
	   
	   public void EnemyRoles() {

		   

		   lastplayerx = playerx;
			lastplayery = playery;
			playerx = (int) Game.s.getX();
			playery = (int) Game.s.getY();
			Chopx = (int)this.getX();
			Chopy = (int)this.getY();
			moving = true;

			gravity++;
			y += gravity;
			
			if(this.overlaps(Game.s)) {
				hurt = true;
			if (knockback != 0)
				knockback -= (knockback / Math.abs(knockback));

			x += knockback;
			if (x >= 924)
			{
				x = 924;
				knockback = 0;
			}
			}
			if (y >= 518) {
				y = 518;
				gravity = 0;
				falling = false;
			} else {
				falling = true;
			}

			
		   if (!sparked)
			   ERI();
		   if(sparked)
			   ERII();
	   }
	   
	   public void ERI() {
			
		   System.out.println(balls[0].active);
			painCheck();
	
		   if(!charged)
		   Charge();
		   if(charged)
		   Attack();
		   if(attacked && charged && !ran)
		   Flee();
		   if(ran)
		   Stand();
		  
	   }
	   
	   public void Charge(){
		   state = RUN;
			if ((x - playerx) > 50) {
				x -= 2;
				moving = true;
			}
			
			if ((x - playerx) <= 50) {
				charged = true;
			}


	   }
	   
	   public void Attack() {

			if ((ball_anim_timer <= 0) && (state == ATTACK)) {
				balls[current_ball].setLocation(x, y);
				balls[current_ball].active = true;
				current_ball++;
				if (current_ball >= balls.length) {
					current_ball = 0;
				}
				this.playAnimation().current = 0;
			}

			
			
			// check that dodger is not in the air
			if (/*!falling && */(ball_anim_timer <= 0)) {
				
						if (ball_timer <= 0) {
							// throw a ball.
							ball_timer = ball_delay;
							//System.out.println("ball throw");
							ball_anim_timer = ball_anim_delay;
							
						}
					
			} else if (ball_anim_timer > 0) {
				state = ATTACK;
				moving = true;
			
			}

			ball_timer--;
			ball_anim_timer--;
			
			for (int i = 0; i < balls.length; i++) {
				if(balls[i].active) {
					balls[i].tick();
					attacked = true;
				}
			}
			//System.out.println(charged);
			
		   
		   

	   }
	   
	   public void Flee(){
		   state = RUN;
			if ((x - playerx) < 300) {
				x += 2;
				moving = true;
				
			}
	
			if ((x - playerx) >= 300) {
				
				ran = true;
			}
		   
		   
	   }
	   
	   public void Stand() {
				
				if (stand_timer > 0) {
					// throw a ball.
				state = STAND;
				this.playAnimation().current = 0;
				//System.out.println(hurt);
				
				
				}
				
				if (stand_timer <= 0) {
					effortReset();

					//ERI();
					//taunted = true;
					//state =RUN;
					
				}
				//System.out.println(taunted);
				stand_timer--;
	   }
	   	   
	  
	   public void ERII() {
		   System.out.println(boom[0].active);
		   if(!stun)
		   Stun();
		   if(stun && roundBoom)
		   Boom();
		  // BombSpace();
		   if(boomPlacement)
		   BombJumpOver();
		   boomPlacement = false;
		   if(ERII_Complete) {
			   secondEffortReset();
			   sparked = false;
		   }
		   
	   }
	   
	   public void Stun() {

		if (stun_timer > 0) {
			   state = RUN;
				if ((x - playerx) < 300) {
					x += 2;
					moving = true;	
				}
				if ((x - playerx) >= 300) {
					
					ran = true;
				}
		   }
		
		if (stun_timer <= 0) {
			stun = true;
			roundBoom = true;
			effortReset();
		}

		stun_timer--;

	   }
	   
	   public void Boom() {
		   if ((boom_anim_timer <= 0) && (state == ATTACK)) {
				boom[current_bomb].setLocation(x-40, y);
				boom[current_bomb].active = true;
				current_bomb++;
				if (current_bomb >= boom.length) {
					current_bomb = 0;
				}
				this.playAnimation().current = 0;
			}

			
			
			// check that dodger is not in the air
			if (/*!falling && */(boom_anim_timer <= 0)) {
				
				if (boom_timer <= 0) {
				// throw a ball.
				boom_timer = boom_delay;
				//System.out.println("ball throw");
				boom_anim_timer = boom_anim_delay;
							
				}
					
				} else if (boom_anim_timer > 0) {
					state = ATTACK;
					moving = true;
			
				}

				boom_timer--;
				boom_anim_timer--;
			
			for (int i = 0; i < boom.length; i++) {
				if(boom[i].active) {
					boom[i].tick();
					boomPlacement = true;
				}
			}

			
		   
	   }
	   
	   public void BombJumpOver() {
		   state = RUN;
			if ((x > boom[0].getX()-(boom[0].getX()/8))) {
				x -= 2;
				y -= 4;
				moving = true;
				
			}
			if ((x <= boom[0].getX()-(boom[0].getX()/8))) {
				//secondEffortReset();
				state = STAND;
				ERII_Complete = true;
			}
			
			
			
			



	   }
	public void tick() {//TODO: When Player is completed, add attack avoidance
		
		// grab the player's current position, check it against his last one.
		
		lastplayerx = playerx;
		lastplayery = playery;
		playerx = (int) Game.s.getX();
		playery = (int) Game.s.getY();
		moving = true;


		if ((ball_anim_timer <= 0) && (state == ATTACK)) {
			balls[current_ball].setLocation(x, y);
			balls[current_ball].active = true;
			current_ball++;
			if (current_ball >= balls.length) {
				current_ball = 0;
			}
			this.playAnimation().current = 0;
		}

		// check that dodger is not in the air
		if (/*!falling && */(ball_anim_timer <= 0)) {
			// if player is moving closer:
			
			/*
			if ((playerx - lastplayerx > 0) && (knockback == 0)) {
				// stand still or move away if too close.
				if ((x - playerx) < w + w) {
					x += 2;
					moving = true;
					state = RUN;
				}
				still_count = 0;
			}

			// if the player is moving further:
			if ((playerx - lastplayerx < 0) && (knockback == 0)) {
				// run up to the player.
				if ((x - playerx) > w + w + w) {
					x -= 2;
					moving = true;
					state = RUN;
				}
				still_count = 0;
			}
*/
			// if player has not moved for two frames:
			if (playerx - lastplayerx == 0) {
				if (still_count > 2) {
					if (ball_timer <= 0) {
						// throw a ball.
						ball_timer = ball_delay;
						//System.out.println("ball throw");
						ball_anim_timer = ball_anim_delay;
					}
				} else {
					still_count++;
				}
				
/*
				if (((x - playerx) > w + w + w) && (knockback == 0)) {
					x -= 2;
					moving = true;
					state = STAND;
				}
*/
				
			}
		} else if (ball_anim_timer > 0) {
			state = ATTACK;
			moving = true;
		
		}

		ball_timer--;
		ball_anim_timer--;

		gravity++;
		y += gravity;

		if (knockback != 0)
			knockback -= (knockback / Math.abs(knockback));

		x += knockback;
		if (x >= 924)
		{
			x = 924;
			knockback = 0;
		}

		if (y >= 518) {
			y = 518;
			gravity = 0;
			falling = false;
		} else {
			falling = true;
		}
		
//		rand_jump_timer--;
	//	if (rand_jump_timer <= 0) {
		//	rand_jump_timer = randy.nextInt(60*10);
//			gravity = -20;
//		}
		
		for (int i = 0; i < balls.length; i++) {
			if(balls[i].active) {
				balls[i].tick();
			}
		}
		
		if (overlaps(Game.s)) {
			System.out.println("touch player");
			knockback = 10;
			//TODO: When Player is completed, check against each Player projectile as well
			//knockback and hp decreases when hit by player
		}
		//System.out.println(Game.s.x);
	}

	public void draw(Graphics g) {
		g.drawRect((int) x, (int) y, w, h);
		
		  
		if (!moving) {
			g.drawImage(Chopplay[state].nextImage(), (int) x, (int) y, null);
			
		}
		else {
			g.drawImage(Chopplay[state].nextImage(), (int) x, (int) y, null);
			
		}
		//System.out.println(moving);
		for (int i = 0; i < balls.length; i++) {
			if(balls[i].active) {
				balls[i].draw(g);
			}
		}
		
		for (int i = 0; i < boom.length; i++) {
			if(boom[i].active) {
				boom[i].draw(g);
			}
	}
	}
	
}
