package Game;

import java.awt.Color;
import java.awt.Graphics;

public class PRectRange extends Rect {

	boolean active;
	boolean foundTarget;


	static String part;
	
	
	public PRectRange(double x, double y, int w, int h) {
		super(x, y, 250, 20);
		
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.BLACK);
		g.drawRect((int) x, (int) y, w, h);
		
	}
	
}
