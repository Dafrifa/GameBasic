package Game;

import java.awt.Graphics;

public class DiveSBlast extends Sprite {

	boolean falling = false;

	static String[] action2 = { "A", "B", "C" };

	boolean active;
	boolean up;
	double basex;
	double basey;

	static String section;
	
	static Animation DiveSink0 = new Animation("fire_A_", 4,1);
	static Animation[] DiveSinkPlay = {DiveSink0};
	
	public DiveSBlast(int x, int y) {
		super(x, y, "fire_", section);
		active = false;
		up = true;
		this.check();
		basex = x;
		basey = 750;
		
		
	}
	
	   public void check() {
		   this.w = w;
		   this.h = h-35;
	   }

		public void tick() {

			System.out.println("Base X :" +basex);
			System.out.println(" X : " +x);

			System.out.println("Base Y :" +basey);
			System.out.println(" Y : " +y);
			if (active) {

				x -= 3;

				if (y > 650) 
				this.reset();
				 else
				this.move();
				
				
				if (overlaps(Game.s)) {
					System.out.println("Hit");
					this.reset();
					active = false;
					//TODO: When Player is completed, decrease health.
				}
			}
			
		}


	public void draw(Graphics g) {
		g.drawRect((int) x, (int) y, w, h);
		if (moving)
			g.drawImage(DiveSinkPlay[0].nextImage(), (int) x, (int) y, null);
		else
			g.drawImage(DiveSinkPlay[0].stillImage(), (int) x, (int) y, null);
	}
}
