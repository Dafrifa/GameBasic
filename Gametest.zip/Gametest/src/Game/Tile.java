package Game;

import java.awt.*;
public class Tile extends Rect{

	Image image;
	double pointLeft;
	double pointRight;
	boolean end = false;
	boolean stop = false;
	public Tile(double x, double y, int w, int h, String file) {
		super(x, y, w, h);
		
		image = Toolkit.getDefaultToolkit().getImage(file).getScaledInstance(w, h, Image.SCALE_DEFAULT);
		/* retool later for true treadmill
		pointLeft =  this.getX()-150;
		pointRight = this.getX()+150;
		*/
		pointLeft =  this.getX()-159;
		pointRight = this.getX()+159;
		
	}

	public void floatingMove() {
		
		//put this on the floor to feel like an tread mill
		if(!stop) {
		if(x >pointLeft && !end) {
			x -=1.5;

		}
		
		if(x <pointRight && end) {
			x +=1.5;

			
		}
		
		if (x<=pointLeft)
			end = true;
		

		if (x>=pointRight)
			end = false;
		
		}
		
		if(Game.s.overlaps(this)&& Game.s.getBottomY() > this.getY()) {
			if(end)
				Game.s.x += 1.5;
			else
				Game.s.x -= 1.5;
		}
			
	}

	public void draw(Graphics g)
	   {
		   g.drawImage(image, (int)x, (int)y, null);

		   g.setColor(Color.blue);
		   g.drawRect((int)x, (int)y,w,h);
	     // g.setColor(Color.blue);

	      
	   }


}
