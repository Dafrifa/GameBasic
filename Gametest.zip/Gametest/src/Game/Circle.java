package Game;

import java.awt.*;


public class Circle {

	double x;
	double y;
	double r;
	
	int A;
	
	public Circle (double x, double y, double r, int A)
	{
		
		this.x =x;
		this.x =y;
		this.x =r;
		
		this.A = A;
	}
	
	public void draw(Graphics g) {
		///g.drawOval(x, y, width, height);
		g.drawOval((int)(x-r),(int)(y-r),(int)(2*r),(int)(2*r));
		
		double cosA = Lookup.cos[A];
		double sinA = Lookup.sin[A];
		g.drawLine((int)(x), (int)(y), (int)(x +r*cosA), (int)(y +r*sinA));
	}
}
