package Game;

import java.awt.Graphics;

public class FlameBlast extends Sprite {


	boolean falling = false;

	static String[] action = { "G", "H", "I" };

	boolean active;
	static String part;
	
	static Animation Flame0 = new Animation("Flame_A_", 8,1);
	static Animation[] FlamePlay = {Flame0};
	
	public FlameBlast(int x, int y) {
		super(x, y, "Flame", part);
		active = false;
		this.check();

		
	}
	
	   public void check() {
		   this.w = 125;
		   this.h = 55;
	   }

	public void tick() {

		if (active) {

			if (overlaps(Game.s)) {
				System.out.println("Hit");

				active = false;
				//TODO: When Player is completed, decrease health.
			}
		}
		if(!active) {

		}
		
	}
	
	public void setFalse() {
		active = false;
	}
	
	public void fireReset() {
		x = -100;
		y = -100;
	}

	public void draw(Graphics g) {
		g.drawRect((int) x, (int) y, w, h);
		//if (moving)
		//	g.drawImage(FlamePlay[0].nextImage(), (int) x, (int) y, 125, 55, null);
		//else
		//	g.drawImage(FlamePlay[0].nextImage(), (int) x, (int) y, 125, 55, null);
	}
}
