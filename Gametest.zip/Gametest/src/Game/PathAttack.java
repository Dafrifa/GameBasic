package Game;

import java.awt.Color;
import java.awt.Graphics;

public class PathAttack extends Rect {
	
	boolean active;

	
	public PathAttack(int x, int y, int w, int h) {
		super(x, y, w, h);
		active = false;
		this.check();

		
	}
	
	   public void check() {
		   this.w = 40;
		   this.h = 40;
	   }
	   
	   public void barrelCheck() {
		   this.w = 50;
		   this.h = 40;
	   }

	public void active() {

		active = true;

		System.out.println(Game.s.checkPose());
		check();
		if(Game.s.facingRight == true)
			x = Game.s.getX()+20;
		else
			x = Game.s.getX()-20;
		
		y = Game.s.y;
	}

	public void enemyActive() {
		check();
		active = true;
		x = Game.s.getX();
		y = Game.s.y;
		if(active) {
		if(overlaps(Game.s))
		{
			active = false;
			Game.s.health = Game.s.health -10;
			this.setLocation(-1000, -1000);
			

		}
		}
	}
	   
	public void activeR() {

		active = true;

		System.out.println(Game.s.checkPose());
		check();
		x = Game.s.getX()+20;
		y = Game.s.y;
	}
	
	public void activeL() {

		active = true;

		System.out.println(Game.s.checkPose());
		check();
		x = Game.s.getX();
		y = Game.s.y;
	}

	public void activeW() {

		active = true;

		System.out.println(Game.s.checkPose());
		barrelCheck();
		if(Game.s.facingRight == true)
			x = Game.s.getX();
		else
			x = Game.s.getX()-5;
		
		
		y = Game.s.y;
	}


	
	
	public void setFalse() {
		active = false;
	}


	public void draw(Graphics g) {
		g.setColor(Color.BLACK);
		g.drawRect((int) x, (int) y, w, h);
	}
}
