package Game;

public class Sprite extends Rect
{
   Animation[] animation;

   boolean selected = true;

   boolean moving = false;
   boolean inAir = false;
   boolean onGround = false;
   boolean facingRight = true;
   boolean act = false;
   
   
   static final int STAND  = 0;
   static final int STANDL = 1;   
   static final int RIGHT  = 2;
   static final int LEFT   = 3;
   
   static final int UP     = 4;
   static final int UPL    = 5;
   static final int RFALL  = 6;
   static final int LFALL  = 7;
   
   static final int DOWN   = 8;

   static final int RATTACK  = 9;
   static final int LATTACK  = 10;
   
   int pose = STAND;

   static final double g = .2;
   double gr = g;
   double d = .2;
   double ty = 9;
   
   double e = y+h;

   public Sprite(int x, int y, String file, String action)
   {
      super(x, y, 20, 50);
   }
   
   public int checkPose() {
	   return pose;
   }

   public boolean checkAir() {
	   return inAir;
   }
   
   public void stopAir() {
	   inAir = false;
	  
   }
   
   public void Attack() {
	   if (pose<9)
	   pose = pose+9;
	  // System.out.println(pose);
   }
   
   public boolean isFacingRight() {
	   return facingRight;
   }
   
   public void moveUpBy(double dy)
   {
      y -= dy;

      moving = true;
      inAir = true;
      if (facingRight)
      pose = UP;
      else 
    	  pose = UPL;
   }
   public void moveDownBy(int dy)
   { 
	  this.trueG(0);
      y += dy;
      moving = true;
      if(inAir) {
      pose = DOWN;
      act = true;
      }
      else 
    	  act = false;
   }
   public void moveLeftBy(int dx)
   {
      x -= dx;

      moving = true;
      if (!inAir)
      pose = LEFT;
      
      facingRight = false;
   }
   public void moveRightBy(int dx)
   {
      x += dx;

      moving = true;
      if (!inAir)
      pose = RIGHT;
      
      facingRight = true;
   }
   
   public void airRight() {
 	  if(inAir && facingRight) 
		  pose = RFALL;

   }
   
   public void airLeft() {
	 	  if(inAir && !facingRight) 
			  pose = LFALL;
   }
   
   public void pushedLeftBy(int dx) {
	   x -= dx;
   }

   
   
   public void falling() {
	   //inAir = true;
	   //if (facingRight)

	   //else 

	  //s this.move();
	   //if
	   if(!act) {
	   inAir = true;
	   airRight();
	   airLeft();
	   }
	   
   }

   public void onGround() {
	   
	   if (facingRight)
	   pose = STAND;
	   else pose = STANDL;
	   inAir= false;
	  
   }
   
   public int Grounded() {
	   if(!inAir) {
	   if (facingRight)
	   pose = STAND;
	   
	   else pose = STANDL;
	   //inAir= false;
	   }
	   return pose;
   }


   public void Jump() {
	  if (ty > 0) {
	   y  -= ty;
	   ty = ty-d;
	  }
      moving = true;
      inAir = true;
      if (facingRight)
      pose = UP;
      else 
    	  pose = UPL;
   }
   
   public void noJump() {
	   ty = 0;
   }
   public void resetJump() {
	   ty = 9;
	   //this.trueG(0);
   }
/*
   public void draw(Graphics g)
   {
	   if (!act && !moving && !inAir)
		   g.drawImage(animation[this.Grounded()].nextImage(), (int)x, (int)y, null);
		   else
	   g.drawImage(animation[pose].nextImage(), (int)x, (int)y, null);
	  
     /* if(moving)
	   g.drawImage(animation[pose].nextImage(), (int)x, (int)y, null);
      
      else {
      
    	  if(inAir && !moving) {
    		  if (facingRight)
    		  pose = RFALL;
    		  else
    			  pose = LFALL;
   
    		  g.drawImage(animation[pose].nextImage(), (int)x, (int)y, null);
    
    	  	}
    	  else {
    		  if (facingRight)
    			//   pose = STAND;
    			//  else pose = STANDL;
         g.drawImage(animation[pose].nextImage(), (int)x, (int)y, null);
      }
      }
      
         moving = false;
     //    ///
      g.setColor(Color.blue);
      if (selected) 
    	  //g.drawRect((int)x, (int)y,w+15,h-10);
   	  g.drawRect((int)x, (int)y,w,h);
      
      /*
      g.drawRect((int)x+5, (int)y+h-4, 25, 4);
      g.drawRect((int)x+5, (int)y, 25, 4);
      g.drawRect((int)x, (int)y, 5, h);
      g.drawRect((int)x+w-5, (int)y, 5, h);
   //   
      g.setColor(Color.black);
      
   }
*/ 
}