package Game;

import java.awt.*;

public class Rect
{
	double x;
	double y;

   int w;
   int h;
   

   double vx = 0;
   double vy = 0;
   double uvx = 0;
   double uvy = 0;
   
   static double u;

   static final double g = .1;

   double ax = 0;
   double ay = g;

   boolean held = false;

   public Rect(double x, double y, int w, int h)
   {
      this.x = x;
      this.y = y;
      this.w = w;
      this.h = h;
   }

   public void grab()
   {
      held = true;
   }

   public void drop()
   {
      held = false;
   }

   public boolean overlaps(Rect r)
   {
      return (x      < r.x + r.w )   &&
             (x + w  > r.x       )   &&
             (y      < r.y + r.h )   &&
             (y + h  > r.y       );
   }

   public boolean contains(int mx, int my)
   {
      return (mx > x) && (mx < x+w) && (my > y) && (my < y+h);
   }


   public void draw(Graphics g)
   {
      g.drawRect((int)x, (int)y, w, h);
   }

   public void moveBy(int dx, int dy)
   {
      //vx +=ax;
      //vy +=ay;

	      //vx =dx;
	      //vy =dy;
      x += dx;
      y += dy;   }

   public void resizeBy(int dw, int dh)
   {
       w += dw;
       h += dh;
   }

   public void setVelocity(double vx, double vy)
   {
      this.vx = vx;
      this.vy = vy;
   }
   
   public void move()
   {
      vx += ax;
      vy += ay;
      
      
      x += vx;
      y += vy;
   }
   
   public void moveGup()
   {    
      uvy+= .1;
      y -=uvy;
   }
   
   public void trueG(double t) {
	   
	   y += t;
	   u = t;
   }
   
   public double getX() {
		 return x;
	   }
   
   public double getY() {
		 return y;
	   }
   
   public double getRightX() {
	   double rx = this.getX()+w;
	   return rx;
   }
   
   public double getBottomY() {
	   double boty = this.getY()+h;
	   return boty;
   }
   
   public void reset()
   {
	 vx = 0;
	 vy = 0;

	 
   }
   
   public void Ureset() {
		 uvx = 0;
		 uvy = 0;
   }
   
   public double getNearBottomY() {
	   double nby = y + (h*3/4);
	   return nby;
   }

   public double checkG() {
	   return u;
   }
   
   public void setLocation(double x, double y)
   {
      this.x = x;
      this.y = y;
   }
      
   /*public boolean contains     * 
    *
    *  */
    

}