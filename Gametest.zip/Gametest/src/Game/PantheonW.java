package Game;

import java.awt.Graphics;


public class PantheonW extends Sprite {
	boolean falling = false;
	boolean hurt = false;
	boolean sparked = false;
	boolean stun = false;
	boolean farStrike = false;
	boolean closeStrike = false;
	boolean leftStrike = false;
	boolean rightStrike = false;
	boolean ERII_Complete = false;
	
	HeroAttack hitbox;
	
	
	
	int step = 0;

	static String[] action = {"st", "gearOne", "gearTwo", "strikeOne", "strikeTwo", "str", "gearOneR", "gearTwoR", "strikeOneR", "strikeTwoR"};

	static final int STAND = 0;
	static final int Gear1 = 1;
	static final int Gear2 = 2;
	static final int Strike1 = 3;
	static final int Strike2 = 4;

	int state = 0;
	int sightRange = -50;
	
	static String part;

	int playerx, playery, lastplayerx, lastplayery;
	int pathx, pathy;
	

	int still_count;

	int stand_timer, stand_delay;
	int fire_timer, fire_delay, fire_anim_timer, fire_anim_delay;
	int stun_timer, stun_delay;
	int rush_timer, rush_delay;
	int last_delay, last_timer;
	int gravity = 0;
	int knockback = 0;
	int hp = 150;
	int rightDistance;
	int leftDistance;
	
	PRectRange sight;
	
	   static Animation PW0 = new Animation("PathW_st_", 3,10);
	   static Animation PW1 = new Animation("PathW_gearOne_", 3,30);
	   static Animation PW2 = new Animation("PathW_gearTwo_", 3,30);
	   static Animation PW3 = new Animation("PathW_strikeOne_", 3,5);
	   static Animation PW4 = new Animation("PathW_strikeTwo_", 3,5);
	   static Animation PW5 = new Animation("PathW_str_", 3,10);
	   static Animation PW6 = new Animation("PathW_gearOneR_", 3,30);
	   static Animation PW7 = new Animation("PathW_gearTwoR_", 3,30);
	   static Animation PW8 = new Animation("PathW_strikeOneR_", 3,5);
	   static Animation PW9 = new Animation("PathW_strikeTwoR_", 3,5);

	  static Animation PWk = new Animation("BLANK", 5,10);
	   
	   static Animation[] PWplay = {PW0, PW1, PW2, PW3, PW4, PW5, PW6, PW7, PW8, PW9};


	public PantheonW(int x, int y) {
		super(x, y, "PathH_", part);
		rush_delay = 180;
		rush_timer = rush_delay;
		still_count = 0;
		stand_delay = 120;
		stand_timer = stand_delay;
		stun_delay = 90;
		stun_timer = stun_delay;
		last_delay = 30;
		last_timer = last_delay;

		playerx = (int) Game.s.getX();
		sight = new PRectRange(x+sightRange, y+2, 200, 300);
		rightDistance = playerx-x;

		facingRight = false;
		
		hitbox = new HeroAttack(50,300,w,h);

	}
 	   public Animation playAnimation() {   
			for(int i = 0; i < PWplay.length; i++) {
				if(state == i)
					return PWplay[i];
			}
			return PWk;
	   }

	 
	   
	  public int checkState(){
		  return state;
	   }
	  
	   public void check() {
		   this.w =37;
		   this.h =38;
	   }
	   
	   public void painCheck() {
		   if (this.overlaps(Game.s)) {
			   
		   	   sparked = true;
		   	   knockback = 40;
		   }
		   
	   }
	   
	   public void switchFace() {
	   if (playerx > x) {
		   facingRight = true;
		   state = state+5;
	   }
	   else 
		   facingRight = false;
	   
	   }

	   public void secondEffortReset() {

		   stun = false;

		   ERII_Complete = false;
	   }
	   
	   public void EnemyRoles() {
		   
		    lastplayerx = playerx;
			lastplayery = playery;
			playerx = (int) Game.s.getX();
			playery = (int) Game.s.getY();
			pathx = (int)this.getX();
			pathy = (int)this.getY();
			moving = true;

			gravity++;
			y += gravity;
			
			if(this.overlaps(Game.s)) {

			if (x >= 924)
			{
				x = 924;
				knockback = 0;
			}
			}
			if (y >= 414) {
				y = 414;
				gravity = 0;
				falling = false;
				
			} else {
				falling = true;
			}


			   ERI();


	   }
	   
	   public void vunerable() {
			if(overlaps(Game.s.hitbox))
			{
				hurt = true;
				Game.s.hitbox.active = false;
					if(hurt) {
					hp = hp-50;;
					hurt = false;
					
					}
			}
	   }
	   
	   public void healthReset() {
		   hp = 150;
	   }
	   
	   public void ERI() {
			
			painCheck();
			
			if (hp <= 0) {
				
				this.setLocation(-300, -300);
				healthReset();
			}
			
			if(step == 0 )
				Stand();
	
			if(step == 1 )
				GearOne();

			if(step == 2 )
				StrikeOne();

			if(step == 3 )
				CoolDownOne();
			
			if(step == 4 )
				GearTwo();

			if(step == 5 )
				StrikeTwo();

			if(step == 6 )
				CoolDownTwo();
			 
	   }
	   
	   public void Stand() {
			if(step == 0){
				vunerable();
			farStrike = false;
			closeStrike = false;
			//if (stand_timer > 0) {
				
			state = STAND;
		
			this.playAnimation().current = 0;
			
			switchFace();
			if (facingRight)
				sightRange = 0;
			else
				sightRange = -150;
			sight.setLocation(x+sightRange, y+2);
			if(sight.overlaps(Game.s)) {

				stand_timer = stand_delay;
				
				
				step = 1;

			}


			}
			
			playerx = (int) Game.s.getX();
			
	   }
	   
	   public void GearOne(){
		   if(step == 1) {
			   
			   state = Gear2;
			   switchFace();
		if ((rush_timer <= 0) && ((state == Gear2)||state == Gear2+5)) {
			state = Strike2;
			   this.playAnimation().current = 0;
		   
		   step=2;
			rush_timer = rush_delay;

			rush_timer = rush_delay;

		}

		   } else if (rush_timer > 0) {
				state = Gear2;
				moving = true;
				this.playAnimation().current = 0;
				
				
			}

			rush_timer--;
			playerx = (int) Game.s.getX();
		   
		   
	   }
	   
	   public void StrikeOne() {
		   if(step == 2) {
			   hitbox.active = true;
			   hitbox.enemyActive();
			   state = Strike2;
			   switchFace();
			   if(!facingRight && !rightStrike)  {
				   
				   hitbox.setLocation(this.getX(), this.getY());
				   
				   if ((x - playerx) > -100) {		
						x -= 6;
						moving = true; 
						leftStrike = true;
						
					}
				   }
			   if(facingRight && !leftStrike) {
				   hitbox.setLocation(this.getX()+20, this.getY());
				   hitbox.enemyActive();
				   if ((playerx - x) > -100) {
						x += 6;
						moving = true;
						rightStrike = true;
						}
				   }
			   
			   if((x - playerx) <= 0 && !facingRight || ((playerx - x) <= 0 && facingRight)){
				   farStrike = false;
					step = 3;
		   }
			   
			   playerx = (int) Game.s.getX();
			   sight.setLocation(x+sightRange, y+2);
		   }

	   
	   }
	   
	   public void CoolDownOne() {
		   vunerable();
		   state = STAND;
		   if (stand_timer <= 0 ) {
			   stand_timer = stand_delay/2;
			   leftStrike = false;
			   rightStrike = false;;
			   step = 0;
		   }
		   stand_timer--;
	   }


	   public void GearTwo(){
		   if(step == 4) {
				if ((rush_timer <= 0) && (state == Gear1)) {
					   this.playAnimation().current = 0;
				   state = Strike1;
				   step=5;
					rush_timer = rush_delay;

					rush_timer = rush_delay;

				}
				/*
				if ((rush_timer <= 0)) {

						rush_timer = rush_delay;

						rush_timer = rush_delay;
						
					}
				*/
				   } else if (rush_timer > 0) {
						state = Gear2;
						moving = true;
						this.playAnimation().current = 0;
					}
					rush_timer--;
					playerx = (int) Game.s.getX();   
		   
	   }
	   	   
	   public void StrikeTwo() {
		   if(step == 5) {

			   state = Strike1;
			   switchFace();
			   if(last_timer > 0 && closeStrike == true) {
			   if(!facingRight) {	
						moving = true;
					}
				   
			   if(facingRight) {
						moving = true;
						}
			   
			   last_timer--;
				   }  
		   
			   if(last_timer <= 0) {
				   closeStrike = false;
				   state = STAND;
				   step = 3;
				   last_timer = last_delay;
				   stand_timer = stand_delay;
				   
			   }
			   
			   playerx = (int) Game.s.getX();
	   
	   }
	   }
	   
	   public void CoolDownTwo() {
		   
	   }
	   
	   public int hpp() {
		   return hp;
	   }
	   
	   

	public void draw(Graphics g) {
		g.drawRect((int) x, (int) y, w, h);
		
		  
		if (!moving) {
			g.drawImage(PWplay[state].stillImage(), (int) x, (int) y, null);
			
		}
		else {
//			if(state == AIM)
//			g.drawImage(pathplay[state].stillImage(), (int) x, (int) y, null);
//			else
			g.drawImage(PWplay[state].nextImage(), (int) x, (int) y, null);
			
		}

		sight.draw(g);
		hitbox.draw(g);
		/*
		
		String print = new String ("Warrior Step: "+step);
        g.drawString(print, 200, 320);
        
        String rush = new String ("Rush: "+rush_timer);
        g.drawString(rush, 300, 320);

        
        String last = new String ("Last: "+last_timer);
        g.drawString(last, 400, 320);
        hpp();
        String stand = new String ("Health: "+hp);
        g.drawString(stand, 500, 320);
        
        String checkState = new String ("Warrior State: "+state);
        g.drawString(checkState, 500, 220);
        
        String checkFace = new String ("FacingRight: "+facingRight);
        g.drawString(checkFace, 600, 220);
        
        rightDistance = (int) (playerx-x);
        String checkStrike = new String ("GapL: "+(playerx-x) + "    GapR: " + (x-playerx) );
        g.drawString(checkStrike, 700, 320);
       
        String LS = new String ("LeftStrike: "+leftStrike);
        g.drawString(LS, 700, 120);
        
        String RS = new String ("RightStrike: "+rightStrike);
        g.drawString(RS, 800, 120);
        */

	}
	
}
