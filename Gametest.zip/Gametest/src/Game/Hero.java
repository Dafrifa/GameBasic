package Game;

import java.awt.Color;
import java.awt.Graphics;




public class Hero extends Sprite 
{
   static String[] action = {"st", "stl", "rt", "lt", "jp", "jplt", "fr", "fl", "dn", "atk", "atkl", "BatkR", "BatkL", "AatkR", "AatkL", "AatkR", "AatkL"};
   static int target = 1; 
   static int speed = 1;
   static String part;
   
   int still_count;
   int strike;
   boolean activeTime = false;
   boolean attackAgain = false;
   long start;
   long timePassed;
   int countdown = 1000;
   int swingTimer, swingTimeReset;
   HeroAttack hitbox;
   int health = 400;
   
   static Animation anim0 = new Animation("Zero_st_", 10,10);
   static Animation anim1 = new Animation("Zero_stl_", 10,10);
   static Animation anim2 = new Animation("Zero_rt_", 11,6);
   static Animation anim3 = new Animation("Zero_lt_", 11,6);
   static Animation anim4 = new Animation("Zero_jp_", 11,10);
   static Animation anim5 = new Animation("Zero_jplt_", 11,10);
   static Animation anim6 = new Animation("Zero_fr_", 5,10);
   static Animation anim7 = new Animation("Zero_fl_", 5,10);
   static Animation anim8 = new Animation("Zero_dn_", 6,30);
   static Animation anim9 = new Animation("Zero_atk_", 11,3);
   static Animation anim10 = new Animation("Zero_atkl_", 11,3);
   static Animation anim11 = new Animation("Zero_BatkR_", 15,2);
   static Animation anim12 = new Animation("Zero_BatkL_", 15,2);
   static Animation anim13 = new Animation("Zero_AatkR_", 10,2);
   static Animation anim14 = new Animation("Zero_AatkL_", 10,2);
   static Animation anim15 = new Animation("Zero_AatkR_", 10,2);
   static Animation anim16 = new Animation("Zero_AatkL_", 10,2);
   static Animation animx = new Animation("Zero_death_", 4,2);
   static Animation blank = new Animation("BLANK", 5,10);
   
   
   static Animation[] play = {anim0, anim1, anim2, anim3, anim4, anim5, anim6, anim7, anim8, anim9, anim10, anim11, anim12, anim13, anim14, anim15, anim16};
   
   public Hero(int x, int y, int speed)
   {
      super(x, y, "Zero_", part);


    	 // System.out.println(action[i]);
    	  
    	hitbox = new HeroAttack(-1000,-1000,w,h);
  		swingTimeReset = 33 ;
  		swingTimer = 0;
  		still_count = 0;

      
   }
   
   public Animation playAnimation() {   
		for(int i = 0; i < play.length; i++) {
			if(this.checkPose() == i)
				return play[i];
		}
		return blank;
   }
   
   
   public void resetAnimation() {
		for(int i = 0; i < play.length; i++) {
			if(this.checkPose() != i)
				play[i].resetImage();
		}
   }
   
   public Animation playAttackAnimation() {   

		return anim9;
   }
   
   public void resetAttack() {
	   strike = 0;
	   activeTime=false;
	   swingTimer = 0;
	   still_count = 0;
	   hitbox.setLocation(-1000, -1000);
	   
   }
   
   public boolean getAttackPermission() {
	   return attackAgain;
   }
   
   public void resetAttackPermission() {
	    attackAgain = false;
   }
   
   public void attackAnimation1() {
	   hitbox.active();
		//System.out.println("Time:  " + start);
	   if(strike == 1) {
				attackAgain = true;
			}
	   
	   if(strike !=1)
	   this.Attack();
	
	   //System.out.println("Can I Attack? " + attackAgain);
		//System.out.println(swingTimer);
		//System.out.println(strike);
	  // if (swingTimer > 0)
	  // hitbox.setLocation(x+20, y);
	   
		if ((swingTimer <= 0) && (pose >= 9)) {
			//System.out.println("Pose :" + pose);
			this.playAnimation().current = 0;
			hitbox.active();
			
			//if(Game.s.checkPose() == 11 || Game.s.checkPose() == 13) {
			//if(Game.s.checkPose() == 11 || Game.s.checkPose() == 13) {
			/*
			if(Game.s.checkPose() == 9 || Game.s.checkPose() == 13 || Game.s.checkPose() == 15) {	
				hitbox.activeR();
			}
			
			if(Game.s.checkPose() == 10 || Game.s.checkPose() == 14 || Game.s.checkPose() == 16) {	
				hitbox.activeL();
			}
			*/
			//if(Game.s.checkPose() == 11 || Game.s.checkPose() == 12) {	
				//hitbox.activeW();
			//}
			
			//System.out.println("good");
			if(activeTime == true)
				strike = 1;
		}

		
		
	if (still_count > 0 && activeTime == false) {

			swingTimer = swingTimeReset;
			activeTime = true;
			
			
		}
		else {
			
			still_count++;
		}
		
		swingTimer--;
		
   }
   
   public void attackAnimationRoll() {
	   hitbox.activeW();

	   if(strike == 1) {
				attackAgain = true;
			}
	   
	   if(strike !=1)
	   this.Attack();
	   
		if ((swingTimer <= 0) && (pose >= 9)) {

			this.playAnimation().current = 0;
			hitbox.activeW();
			

			//System.out.println("good");
			if(activeTime == true)
				strike = 1;
		}

		
		
	if (still_count > 0 && activeTime == false) {

			swingTimer = swingTimeReset;
			activeTime = true;
			
			
		}
		else {
			
			still_count++;
		}
		
		swingTimer--;
		
   }
   

   public int checkStrike() {
	   return strike;
   }
   
   
   public void check() {
	   this.w = w+15;
	   this.h = h-10;
   }
   
   public void setSpeed(){
	   speed = 1;
   }
   
   public static int animationSpeed ()
   {
	   speed =10;
	   return speed;
   }
   
   public void draw(Graphics g)
   {
	   resetAnimation();
	   /*
	      g.drawImage(anim0.nextImage(), -1000,-100, null);
	      g.drawImage(anim1.nextImage(), -1000,-100, null);
	      g.drawImage(anim2.nextImage(), -1000,-100, null);
	      g.drawImage(anim3.nextImage(), -1000,-100, null);
	      g.drawImage(anim4.nextImage(), -1000,-100, null);
	      g.drawImage(anim5.nextImage(), -1000,-100, null);
	      g.drawImage(anim6.nextImage(), -1000,-100, null);
	      g.drawImage(anim7.nextImage(), -1000,-100, null);
	      g.drawImage(anim8.nextImage(), -1000,-100, null);
	      g.drawImage(anim9.nextImage(), -1000,-100, null);
	      g.drawImage(anim10.nextImage(), -1000,-100, null);
	      g.drawImage(anim11.nextImage(), -1000,-100, null);
	      g.drawImage(anim12.nextImage(), -1000,-100, null);
	      g.drawImage(anim13.nextImage(), -1000,-100, null);
	      g.drawImage(anim14.nextImage(), -1000,-100, null);
	      g.drawImage(anim15.nextImage(), -1000,-100, null);
	      g.drawImage(anim16.nextImage(), -1000,-100, null);
	   */
	   if (health >0) {
	   //if (!act && !moving && !inAir)
	//	   g.drawImage(this.playAnimation().nextImage(), (int)x, (int)y, null);
	   //else {
		   
			  if(this.checkPose() == 10)
			  g.drawImage(this.playAnimation().nextImage(), (int)x-20, (int)y, null);
			  
			  else {
				  if(this.checkPose() == 8)
					  g.drawImage(this.playAnimation().downSetImage(), (int)x, (int)y, null);
				  else
				  g.drawImage(this.playAnimation().nextImage(), (int)x, (int)y, null);
			  }
			  //System.out.println(this.checkPose());
		   /*
			  if(this.checkPose() != 10 || this.checkPose() != 14 || this.checkPose() != 16)
			  g.drawImage(this.playAnimation().nextImage(), (int)x, (int)y, null);
			  
			  else
				  g.drawImage(this.playAnimation().nextImage(), (int)x-20, (int)y, null);
			  */
		   }
	   else 
		   g.drawImage(animx.onceImage(), (int)x, (int)y, null);
	   
      g.setColor(Color.blue);
      if (selected) 
   	  g.drawRect((int)x, (int)y,w,h);

      g.setColor(Color.black);
      
      hitbox.draw(g);
      

      
      
   }


   
   
}