package Game;

import java.awt.Graphics;


public class PantheonH extends Sprite {
	boolean falling = false;
	boolean hurt = false;
	boolean sparked = false;
	boolean stun = false;

	boolean ERII_Complete = false;
	
	int step = 0;

	static String[] action = {"st", "rnL", "atk", "aim", "hold", "stR", "rnR","atkR", "aimR","holdR"};

	static final int STAND = 0;
	static final int RUN = 1;
	static final int ATTACK = 2;
	static final int AIM = 3;
	static final int HOLD = 4;

	int state = 0;
	
	static String part;

	int playerx, playery, lastplayerx, lastplayery;
	int pathx, pathy;

	int still_count;

	int stand_timer, stand_delay;
	int fire_timer, fire_delay, fire_anim_timer, fire_anim_delay;
	int stun_timer, stun_delay, reset_timer, reset_delay;
	int last_delay, last_timer;

	PathBullet fire;

	int gravity = 0;
	int knockback = 0;

	int current_fire = 0;

	int hp = 50;
	
	   static Animation pathanim0 = new Animation("PH_st_", 3,10);
	   static Animation pathanim1 = new Animation("PH_rnL_", 3,10);
	   static Animation pathanim2 = new Animation("PH_atk_", 2,10);
	   static Animation pathanim3 = new Animation("PH_aim_", 3,10);
	   static Animation pathanim4 = new Animation("PH_hold_", 3,10);
	   static Animation pathanim5 = new Animation("PH_str_", 3,10);
	   static Animation pathanim6 = new Animation("PH_rnR_", 3,10);
	   static Animation pathanim7 = new Animation("PH_atkR_", 2,10);
	   static Animation pathanim8 = new Animation("PH_aimR_", 3,10);
	   static Animation pathanim9 = new Animation("PH_holdR_", 3,10);
	   static Animation pathblank = new Animation("BLANK", 5,10);
	   
	   static Animation[] pathplay = {pathanim0, pathanim1, pathanim2, pathanim3, pathanim4, pathanim5, pathanim6, pathanim7, pathanim8, pathanim9};


	public PantheonH(int x, int y) {
		super(x, y, "PathH_", part);
		
		fire_delay = 35;
		fire_timer = fire_delay;
		fire_anim_delay = 14;
		fire_anim_timer = 0;
		still_count = 0;
		stand_delay = 90;
		stand_timer = stand_delay;
		stun_delay = 90;
		stun_timer = stun_delay;
		reset_delay = 180;
		reset_timer = reset_delay;
		last_delay = 60;
		last_timer = last_delay;

		playerx = (int) Game.s.getX();
		
		fire = new PathBullet(-100,-100);

		facingRight = false;

	}
 	   public Animation playAnimation() {   
			for(int i = 0; i < pathplay.length; i++) {
				if(state == i)
					return pathplay[i];
			}
			return pathblank;
	   }

	 
	   
	  public int checkState(){
		  return state;
	   }
	  
	   public void check() {
		   this.w =40;
		   this.h =40;
	   }
	   
	   public void painCheck() {
		   if (this.overlaps(Game.s)) {
			   hurt = true;
		   	   sparked = true;
		   	   knockback = 40;
		   }
		   
	   }
	   
	   public void switchFace() {
	   if (playerx > x) {
		   facingRight = true;
		   state = state+5;
	   }
	   else 
		   facingRight = false;
	   
	   }

	   public void secondEffortReset() {

		   stun = false;

		   ERII_Complete = false;
	   }
	   
	   public void EnemyRoles() {
		   
		    lastplayerx = playerx;
			lastplayery = playery;
			playerx = (int) Game.s.getX();
			playery = (int) Game.s.getY();
			pathx = (int)this.getX();
			pathy = (int)this.getY();
			moving = true;
			
			if(this.overlaps(Game.s)) {
				hurt = true;
			if (knockback != 0)
				knockback -= (knockback / Math.abs(knockback));


				
			} else {
				falling = true;
			}
			fire.tick();

			   ERI();


	   }
	   

	   public void vunerable() {
			if(overlaps(Game.s.hitbox))
			{
				hurt = true;
				Game.s.hitbox.active = false;
					if(hurt) {
					hp = hp-50;;
					hurt = false;
					
					}
			}
	   }
	   
	   
	   public void healthReset() {
		   hp = 100;
	   }
	   
	   public void ERI() {
			
			painCheck();
	
			vunerable();
			if(overlaps(Game.s.hitbox))
			{
					hp -= 50;
			}
			
			if (hp <= 0) {
				
				this.setLocation(-300, -300);
			}
			
			if(step == 0 )
		   Charge();

			if(step == 1 )
		   Attack();

			if(step == 2 )
		   Attacking();

			if(step == 3 )
		   Stand();

	   }
	   
	   public void Charge(){
		   if(step == 0) {
		
		   fire.tick();
		   state = RUN;
		   switchFace();
		   if(!facingRight) {
		   if ((x - playerx) > 350) {
				
				x -= 2;
				moving = true;
			}
		   }
		   if(facingRight) {
			if ((playerx - x) > 350) {
				x += 2;
				moving = true;
				}
		   }
			
			if ( ((x - playerx) <= 350 && !facingRight) || ((playerx - x) <= 350) && facingRight) {
				
				step=1;
			}
			playerx = (int) Game.s.getX();
		   }
		   
	   }
	   
	   public void Attack() {
		   	if(step == 1) {
		   		
		   		fire.tick();
		   		
			if ((fire_anim_timer <= 0) /* && (state == AIM)*/) {
				if (!facingRight) {
					state = ATTACK;
					
				
					fire.setLocation(x, y+7);
				}
				else
					if(facingRight) {
						state = 7;
						
						
					fire.setLocation(x+35, y+7);
					}
					fire.active = true;
				
				this.playAnimation().current = 0;
			}

			if ((fire_anim_timer <= 0)) {
				
						if (fire_timer <= 0) {

							fire_timer = fire_delay;

							fire_anim_timer = fire_anim_delay;
							
						}
					
			} else if (fire_anim_timer > 0) {
				if(!facingRight)
				state = AIM;
				else
					state = 9;
				moving = true;
			
			}

			fire_timer--;
			fire_anim_timer--;

			if(fire.active) {
				fire.tick();
				fire_anim_timer = fire_anim_delay;
				step=2;

				
			}
			//else
			//	fire.fireReset();
			playerx = (int) Game.s.getX();
		   	}
	   }
	   
	   public void Attacking() {
		   if(step == 2) {
			   
			   fire.tick();

		   if(last_timer>0) {

			   state = ATTACK;
			   switchFace();
		   }
		  
			if (last_timer <= 0) {

				//fire.active = false;
				//fire.fireReset();
				last_timer = last_delay;
				step=3;
			}
			
			last_timer--;
			playerx = (int) Game.s.getX();
		   }
	   }
	   
	   public void Stand() {
				if(step == 3){
					
					fire.tick();
				if (stand_timer > 0) {
				
				state = HOLD;
				switchFace();
				this.playAnimation().current = 0;
				}
				
				if (stand_timer <= 0) {

					stand_timer = stand_delay;
					step = 0;

				}

				stand_timer--;
				playerx = (int) Game.s.getX();
				}
	   }
	   
	   public void Stun() {
		   if(step == 5) {


		if (stun_timer > 0) {
			   state = RUN;
				if ((x - playerx) < 300) {
					x += 2;
					moving = true;	
				}
				if ((x - playerx) >= 300) {
					
				
				}
		   }
		
		if (stun_timer <= 0) {
			hurt = false;
			step = 6;

		}

		stun_timer--;
		playerx = (int) Game.s.getX();
		   }
	   }


	public void draw(Graphics g) {
		g.drawRect((int) x, (int) y, w, h);
		
		  
		if (!moving) {
			if(state == AIM && pathplay[AIM].Imagelength() == 3)
			g.drawImage(pathplay[state].stillImage(), (int) x, (int) y, null);
			
		}
		else {
			if(state == AIM)
			g.drawImage(pathplay[state].stillImage(), (int) x, (int) y, null);
//			else
			g.drawImage(pathplay[state].nextImage(), (int) x, (int) y, null);
			
		}

		fire.draw(g);
		
		/*
		String print = new String ("Step: "+step);
        g.drawString(print, 200, 320);

        
        String hu = new String ("Hurt: "+hurt);
        g.drawString(hu, 100, 220);
        
        String spark = new String ("Spar: "+sparked);
        g.drawString(spark, 200, 220);
        
        String checkFace = new String ("FacingRight: "+facingRight);
        g.drawString(checkFace, 300, 220);
        
        String checkState = new String ("State: "+state);
        g.drawString(checkState, 400, 220);
        */
        

	}
	
}
