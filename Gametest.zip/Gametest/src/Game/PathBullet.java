package Game;

import java.awt.Graphics;

public class PathBullet extends Sprite {


	boolean falling = false;

	static String[] action = { "G", "H", "I" };

	boolean active;
	boolean up;
	double basex;
	double basey;
	double xStart = x;
	boolean shotR = false;
	boolean shotL = false;
	

	static String part;
	
	static Animation PathBullet0 = new Animation("PathH_shot_", 4,6);
	static Animation[] PathBulletPlay = {PathBullet0};
	
	public PathBullet(int x, int y) {
		super(x, y, "PathBullet", part);
		active = false;
		up = true;
		this.check();
		basex = x;
		basey = 750;
		
	}
	
	   public void check() {
		   this.w = 5;
		   this.h = 5;
	   }

	public void tick() {
		
		if (active) {
			
			if(Game.s.x < x && !shotR) 
				shotL = true;
			if(Game.s.x > x && !shotL)
				shotR = true;
			
			if(shotL)
				x -= 3;
			if(shotR)
				x += 3;
			
			if (x < xStart-1000) {
				active = false;
			}
			
			if (overlaps(Game.s)) {
				
				Game.s.health = Game.s.health -5;
				this.fireReset();
				active = false;

			}
		}
		if(!active) {

		}
		
	}
	
	public void setFalse() {
		active = false;
	}
	
	public void fireReset() {
		x = -100;
		y = -100;
		shotL = false;
		shotR = false;
	}

	public void draw(Graphics g) {
		g.drawRect((int) x, (int) y, w, h);
		if (moving)
			g.drawImage(PathBulletPlay[0].nextImage(), (int) x, (int) y, 5, 5, null);
		else
			g.drawImage(PathBulletPlay[0].nextImage(), (int) x, (int) y, 5, 5, null);
		
		/*
	       	String checkFace = new String ("shotR: "+shotR);
	        g.drawString(checkFace, 600, 220);
	        
	        String checkState = new String ("shotL: "+ shotL);
	        g.drawString(checkState, 500, 220);
	        */
	}
}
