
public class CardStack {
	private Card [] stack;
	private int top;
	private int size;
	
	public CardStack() {
		top = -1;
		size = 50;
		stack = new Card [50];
	}
	
	public CardStack(int size) {
		top = -1;
		this.size = size;
		stack = new Card [this.size];
	}
	
	public boolean push(Card item) {
		if(!isFull()) {
		top++;
		stack[top] = item;
		return true;
		}
		else return false;
	}
	
	public Card pop() {
		return (stack[top--]);
	}
	
	public boolean isFull() {
		return (top == stack.length);
	}
	
	public boolean isEmpty() {
		return (top == -1);
	}
	
	
}
