
public class Card {

	private String name;
	private String type;
	private int number;
	
	public Card(String name, String type, int number) {
		this.name = name;
		this.type = type;
		this.number = number;
	}
	
	public String toString() {
		return "Name: " + this.name + " Type: " +this.type + " Number: " +this.number;
	}
	
}
