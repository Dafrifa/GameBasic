
public class Main {
	public static void main(String[] args) {
//		Stack stack  = new Stack();
//		if(!stack.isFull()) {
//			stack.push(1);
//			stack.push(3);
//			stack.push(5);
//			stack.push(7);
//			stack.push(22);
//		}
//		
//		System.out.println(stack.pop());
//		System.out.println(stack.pop());
//		System.out.println(stack.pop());
//		System.out.println(stack.pop());
//		System.out.println(stack.pop());
		Card card1 = new Card("Dark Magician", "Spellcaster", 2500);
		Card card2 = new Card("Blue Eyes White Dragon", "Dragon", 3000);
		
		CardStack deck = new CardStack();
		
		deck.push(card1);
		deck.push(card2);
		
		System.out.println(deck.pop().toString());
		System.out.println(deck.pop());
	}
	
}
