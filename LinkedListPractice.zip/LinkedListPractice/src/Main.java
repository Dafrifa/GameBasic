
public class Main {

	public static void main (String[] args) {
		LinkedList list = new LinkedList(4);
		list.insertItem(6);
		list.insertItem(24);
		list.printList();
		
		list.deleteItem(6);
		
		list.printList();
	}
}
